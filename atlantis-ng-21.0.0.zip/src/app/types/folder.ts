export interface Folder {
    name: string;
    icon: string;
    size: string;
}
